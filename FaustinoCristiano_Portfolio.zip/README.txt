Traits: Embracing, but not vague
	Professional, but not too impersonal
	Clean, but not insufficient (this one about the people looking at the design, and thinking if I could do their work direct to the point, or if I would garnish my project for too long).

My brand would be a programmer that face challenges, and is excited about working with different things and ideas.


PS: The lightbox is implemented in the projects page for two of the projects because I didn't have pictures of the other ones, since they were mostly private softwares